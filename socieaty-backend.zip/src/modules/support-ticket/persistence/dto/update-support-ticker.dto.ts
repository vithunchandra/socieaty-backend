import { SupportTicketStatus } from "../../../../enums/support-ticket.enum";

export class UpdateSupportTicketDto {
	status: SupportTicketStatus
}
