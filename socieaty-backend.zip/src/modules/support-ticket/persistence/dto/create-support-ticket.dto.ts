export class CreateSupportTicketDto{
    title: string;
    description: string;
    userId: string;
}

