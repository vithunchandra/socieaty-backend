export class CreateSupportTicketMessageDto {
	message: string
	supportTicketId: string
	userId: string
}
