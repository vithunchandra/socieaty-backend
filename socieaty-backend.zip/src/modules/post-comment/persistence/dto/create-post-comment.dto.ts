export class CreatePostCommentDto{
    postId: string 
    userId: string 
    text: string
}