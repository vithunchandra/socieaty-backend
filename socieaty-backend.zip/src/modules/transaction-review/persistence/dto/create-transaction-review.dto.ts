export class createTransactionReviewDto{
    rating: number
    review: string
    transactionId: string
}