class GetAllUnverifiedRestaurantQueryDto {
	name?: string
	themeIds?: number[]
}

