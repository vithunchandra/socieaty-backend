export class UpdateRestaurantConfigDto {
    maxPerson: number
    minCostPerPerson: number
    timeLimit: number
}

