export class RestaurantTheme{
    id: number
    name: string
}