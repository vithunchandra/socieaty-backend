export class CreatePostHashtagDto{
    tags: string[]
}