export class PostHashtag{
    id: string
    tag: string
}