export class UpdateCustomerDataDto {
    bio: string
}
