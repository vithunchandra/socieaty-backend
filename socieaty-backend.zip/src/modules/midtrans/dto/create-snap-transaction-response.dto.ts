export class CreateSnapTransactionResponseDto {
    token: string
    redirectUrl: string
}
