export class PostMedia{
    id: string
    url: string
    type: string
    postId: string
    extension: string
    videoThumbnailUrl?: string
}