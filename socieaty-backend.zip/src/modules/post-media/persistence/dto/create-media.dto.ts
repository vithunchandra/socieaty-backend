export class CreateMediaDto {
	url: string
	type: string
	post: string
	extension: string
	videoThumbnailUrl?: string
}