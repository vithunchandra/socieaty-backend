export class FindUserByIdDto {
	user_id: string

	isFilterActive: boolean
}
