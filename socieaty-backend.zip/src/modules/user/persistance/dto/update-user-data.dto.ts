export class UpdateUserDataDto {
    name: string
    phoneNumber: string
    profilePictureUrl?: string
 }
