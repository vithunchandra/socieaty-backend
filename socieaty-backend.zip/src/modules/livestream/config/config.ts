export const LivekitConfig = {
    apiKey: process.env.LIVEKIT_API_KEY ? process.env.LIVEKIT_API_KEY : "API4NC5bVaNMmCq",
    apiSecret: process.env.LIVEKIT_API_SECRET ? process.env.LIVEKIT_API_SECRET : "SioFeYcM5iegMWCKRKiT99I0miJ4CXOn0AQxCELN41D",
    host: process.env.LIVEKIT_HOST ? process.env.LIVEKIT_HOST : "wss://foodie-3s08moxr.livekit.cloud"
}