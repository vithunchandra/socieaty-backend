export class LiveRoomMetadata{
    roomTitle: string
    ownerId: string
}