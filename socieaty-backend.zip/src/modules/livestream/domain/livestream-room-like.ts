export class LivestreamRoomLike {
	roomName: string
	likes: number

	constructor(roomName: string, likes: number) {
		this.roomName = roomName
		this.likes = likes
	}
}
