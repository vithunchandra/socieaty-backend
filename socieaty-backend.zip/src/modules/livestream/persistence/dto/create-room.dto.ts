export class CreateRoomDto{
    roomName: string 
    ownerId: string 
    roomTitle: string
}