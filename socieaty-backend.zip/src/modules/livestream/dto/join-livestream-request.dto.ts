export class JoinLivestreamRequestDto{
    roomName: string
}