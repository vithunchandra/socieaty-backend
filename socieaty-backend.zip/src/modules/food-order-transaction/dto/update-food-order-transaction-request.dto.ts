import { FoodOrderStatus } from '../../../enums/food-order.enum'

export class UpdateFoodOrderTransactionRequestDto {
	status: FoodOrderStatus
}
