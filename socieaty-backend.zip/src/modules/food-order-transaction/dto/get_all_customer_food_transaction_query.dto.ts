import { FoodOrderStatus } from "../../../enums/food-order.enum";

export class GetAllCustomerFoodTransactionQueryDto {
	status: FoodOrderStatus[]
}

