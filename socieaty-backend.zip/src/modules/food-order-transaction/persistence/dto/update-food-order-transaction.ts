import { FoodOrderStatus } from 'src/enums/food-order.enum'

export class UpdateFoodOrderTransactionDto {
	status: FoodOrderStatus
}
