export class CreateTransactionMessageDto {
    message: string
    transactionId: string
    userId: string
}
