export class UpdateFoodMenuDto {
	name: string
	price: number
	description: string
	menuPictureUrl: string
	estimatedTime: number
	categories: number[]
}
