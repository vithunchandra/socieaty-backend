export class GetAllFoodMenuDto {
	priceConditionIds?: string[]
	minRating?: number
	categoryIds?: number[]
	searchQuery?: string
}
