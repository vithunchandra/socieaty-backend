export class MenuCategory {
	id: number
	name: string
}
