export class TopupRequestDto {
	amount: number
	customerName: string
	customerEmail: string
	description: string
}
