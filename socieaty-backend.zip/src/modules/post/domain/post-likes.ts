export class PostLike{
    postId: string
    userId: string
    userName: string
}