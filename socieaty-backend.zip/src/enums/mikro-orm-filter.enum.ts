export enum MikroOrmFilter{
    EXISTS = "exists",
    DELETED = "deleted"
}