export enum PaginationDirection{
    FORWARD = 'forward',
    BACKWARD = 'backward'
}