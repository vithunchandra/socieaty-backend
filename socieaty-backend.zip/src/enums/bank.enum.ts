export enum BankEnum {
	BNI = 'bni',
	BRI = 'bri',
	BCA = 'bca',
	MANDIRI = 'mandiri'
}
